extends CharacterBody2D

# --- Movement Constants ---
const GRAVITY: float = 900.0
const JUMP_VELOCITY: float = -300.0
const TERMINAL_VELOCITY: float = 700.0

# --- Rotation Tuning ---
const ROTATION_SPEED: float = 8.0
const MAX_UPWARD_ANGLE: float = -30.0   # Degrees (tilted up)
const MAX_DOWNWARD_ANGLE: float = 70.0  # Degrees (nosediving)
const FALL_ROTATION_THRESHOLD: float = 100.0 # Velocity at which bird starts nosediving

# --- Node References ---
@onready var animated_sprite: AnimatedSprite2D = $AnimatedSprite2D
@onready var audio_player: AudioStreamPlayer2D = $AudioStreamPlayer2D
  
func _physics_process(delta: float) -> void:
	# 1. Apply Gravity (Only vertically, no horizontal movement)
	if not is_on_floor():
		velocity.y += GRAVITY * delta
		if velocity.y > TERMINAL_VELOCITY:
			velocity.y = TERMINAL_VELOCITY

	# 2. Handle Jump Input
	if Input.is_action_just_pressed("ui_accept") or Input.is_action_just_pressed("click"):
		velocity.y = JUMP_VELOCITY
		# Play the flap animation from the beginning whenever we jump
		animated_sprite.play("Flap")
		# Play the flap sound
		audio_player.play()

	# 3. Apply Movement
	move_and_slide()
	
	# 4. Handle Animations and Rotations
	_handle_animations()
	_handle_rotation(delta)

## Manages the 3-frame "Flap" animation based on vertical movement
func _handle_animations() -> void:
	# If the animation isn't currently playing, map frames to velocity
	if not animated_sprite.is_playing():
		if velocity.y < 0:
			# Ascending: Flap Up (Frame 2)
			animated_sprite.frame = 2
		elif velocity.y > FALL_ROTATION_THRESHOLD:
			# Nosediving: Flap Down (Frame 0)
			animated_sprite.frame = 0
		else:
			# Neutral/Transition: Flap Mid (Frame 1)
			animated_sprite.frame = 1

## Replicates the iconic Flappy Bird tilt
func _handle_rotation(delta: float) -> void:
	var target_rotation: float = 0.0
	
	if velocity.y < 0:
		# Point upward instantly or quickly when jumping
		target_rotation = deg_to_rad(MAX_UPWARD_ANGLE)
		rotation = lerp_angle(rotation, target_rotation, ROTATION_SPEED * 2 * delta)
	elif velocity.y > FALL_ROTATION_THRESHOLD:
		# Snappily tilt downwards into a nosedive when falling fast
		target_rotation = deg_to_rad(MAX_DOWNWARD_ANGLE)
		rotation = lerp_angle(rotation, target_rotation, ROTATION_SPEED * delta)
	else:
		# Level out slightly in mid-air
		target_rotation = deg_to_rad(0.0)
		rotation = lerp_angle(rotation, target_rotation, ROTATION_SPEED * delta)

## Triggered when the bird collides with an obstacle or the ground
## Make sure to connect your Area2D/Body signals to this function or check collisions here
func _on_collision_detected(collider: Node2D) -> void:
	# TODO: Implement game over logic here
	# e.g., freeze movement, play crash sound, trigger game over UI
	print("Collided with: ", collider.name)
	get_parent().gameover()
