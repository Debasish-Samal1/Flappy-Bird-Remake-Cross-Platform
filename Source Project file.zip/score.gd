extends Node2D


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass
func increase_score(): 
	if get_child(1).frame != 9:
		get_child(1).frame = get_child(1).frame + 1
	elif get_child(1).frame == 9 and get_child(0).frame == 9:
		pass
	else:  
		get_child(1).frame = 0
		get_child(0).frame = get_child(0).frame + 1
		
