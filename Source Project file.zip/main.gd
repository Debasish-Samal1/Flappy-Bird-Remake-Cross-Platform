extends Node2D

# --- Configuration ---
@export var pipe_scene: PackedScene 
@export var spawn_interval: float = 1.5 
@export var pipe_speed: float = 200.0 
@export var pipe_y_variance: float = 150.0 

# --- Nodes & Tracking ---
var spawn_timer: Timer
var active_pipes: Array[Node2D] = []
var player: Node2D = null

var score: int = 0
var is_game_over: bool = false
var is_started: bool = false # NEW: Tracks if the game has begun

func _ready() -> void:
	player = get_node_or_null("Player")
	
	# Initial Setup: Hide player and score, ensure message is visible
	if player:
		player.visible = false
	else:
		push_warning("Player node not found at root.")
		
	$Score.visible = false
	$Message.visible = true
	$Gameover.visible = false

	# Setup the timer, but do NOT start it yet
	spawn_timer = Timer.new()
	spawn_timer.wait_time = spawn_interval
	spawn_timer.autostart = false # Changed to false
	spawn_timer.timeout.connect(_spawn_pipe)
	add_child(spawn_timer)

# NEW: Listen for user input to start the game
func _input(event: InputEvent) -> void:
	# Ignore input if game has already started or ended
	if is_started or is_game_over:
		return
		
	# "ui_accept" is Godot's default mapping for Enter and Spacebar.
	# We also allow starting by clicking the left mouse button.
	if event.is_action_pressed("ui_accept") or (event is InputEventMouseButton and event.pressed):
		start_game()

# NEW: Handles the transition from the menu to gameplay
func start_game() -> void:
	is_started = true
	$Message.visible = false
	
	if player:
		player.visible = true
		
	$Score.visible = true
	
	# Start the game loop
	spawn_timer.start()
	_spawn_pipe()

func _process(delta: float) -> void:
	# Stop updating if the game hasn't started OR is over
	if not is_started or is_game_over:
		return
		
	_move_and_score_pipes(delta)

func _spawn_pipe() -> void:
	# Guard clause: Stop spawning new objects after game over
	if is_game_over or not pipe_scene:
		return
		
	var new_pipe = pipe_scene.instantiate() as Node2D
	var spawn_x = get_viewport_rect().size.x + 100 
	var center_y = get_viewport_rect().size.y / 2.0
	var random_y = center_y + randf_range(-pipe_y_variance, pipe_y_variance)
	
	new_pipe.position = Vector2(spawn_x, random_y)
	new_pipe.set_meta("scored", false)
	
	# --- Collision Detection Setup ---
	var detection_area = new_pipe
	
	if detection_area:
		detection_area.body_entered.connect(_on_pipe_body_entered)
	else:
		push_error("Spawned pipe scene missing an Area2D node. Collision will not register.")
	
	add_child(new_pipe)
	active_pipes.append(new_pipe)

func _move_and_score_pipes(delta: float) -> void:
	var viewport_left_bound = -200 
	var pipes_to_remove: Array[Node2D] = []

	for pipe in active_pipes:
		if not is_instance_valid(pipe):
			continue
			
		pipe.position.x -= pipe_speed * delta
		
		if player and not pipe.get_meta("scored"):
			if player.position.x > pipe.position.x:
				pipe.set_meta("scored", true)
				_increment_score()
				$Score.increase_score() # Assumes a method exists on the Score node
				
		if pipe.position.x < viewport_left_bound:
			pipes_to_remove.append(pipe)

	for pipe in pipes_to_remove:
		active_pipes.erase(pipe)
		pipe.queue_free()

func _on_pipe_body_entered(body: Node2D) -> void:
	# Ensure it's the player colliding, not another object
	if body == player:
		trigger_game_over()

func trigger_game_over() -> void:
	if is_game_over:
		return 
		
	is_game_over = true
	spawn_timer.stop() 
	$Gameover.visible = true
	print("Game Over! Final Score: ", score)
	
	await get_tree().create_timer(5.0).timeout
	get_tree().reload_current_scene()

func _increment_score() -> void:
	score += 1
	print("Score: ", score)
